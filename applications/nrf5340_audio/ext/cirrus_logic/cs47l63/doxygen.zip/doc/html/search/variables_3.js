var searchData=
[
  ['devid',['devid',['../structcs47l63__t.html#a35aba9cedc248c0ae61e4b2291b68991',1,'cs47l63_t']]],
  ['disable_5firq',['disable_irq',['../structbsp__driver__if__t.html#ab7dde8dfca33bc4f538539e185c7c840',1,'bsp_driver_if_t']]],
  ['dsp_5fcore',['dsp_core',['../structcs47l63__dsp__t.html#a475b83dd79090b96bb4d4951ce672ff7',1,'cs47l63_dsp_t']]],
  ['dsp_5finfo',['dsp_info',['../structcs47l63__t.html#af7ee3d3626d7f294c39ce364088ddf85',1,'cs47l63_t']]]
];
