var searchData=
[
  ['n_5firq_5fregs',['N_IRQ_REGS',['../cs47l63_8c.html#a2a8e14d230dd058ee2ebc4336b280d35',1,'cs47l63.c']]],
  ['n_5fram_5fbanks',['n_ram_banks',['../structcs47l63__dsp__t.html#a22379e54ca8273f1ba543854d77cb62c',1,'cs47l63_dsp_t']]],
  ['notification_5fcb',['notification_cb',['../structcs47l63__bsp__config__t.html#a760e2b3f039ea157261716cd27f08606',1,'cs47l63_bsp_config_t']]],
  ['notification_5fcb_5farg',['notification_cb_arg',['../structcs47l63__bsp__config__t.html#a0a89fe90ce05e0db0164a7ba131892ff',1,'cs47l63_bsp_config_t']]]
];
