var searchData=
[
  ['ram_5fbanks',['ram_banks',['../structcs47l63__dsp__t.html#a6be26ad80cb7fbdf80c1724fdbd922df',1,'cs47l63_dsp_t']]],
  ['register_5fgpio_5fcb',['register_gpio_cb',['../structbsp__driver__if__t.html#a11e60a843ba9d408cdb6c781af0b9705',1,'bsp_driver_if_t']]],
  ['revid',['revid',['../structcs47l63__t.html#ac49dfa21649e61858ab8d680c26c2d21',1,'cs47l63_t']]]
];
