var searchData=
[
  ['n_5firq_5fregs',['N_IRQ_REGS',['../cs47l63_8c.html#a2a8e14d230dd058ee2ebc4336b280d35',1,'cs47l63.c']]]
];
