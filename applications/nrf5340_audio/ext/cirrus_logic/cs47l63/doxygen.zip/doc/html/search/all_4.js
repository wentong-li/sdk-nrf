var searchData=
[
  ['enable_5firq',['enable_irq',['../structbsp__driver__if__t.html#acc9c058938adde4ff740af1eb640af5b',1,'bsp_driver_if_t']]],
  ['event_5fflags',['event_flags',['../structcs47l63__t.html#acabd4c550a2ece50476545f4b816f505',1,'cs47l63_t']]]
];
