var searchData=
[
  ['value',['value',['../structcs47l63__register__encoding.html#af64df75395a3653a562497f8186d57be',1,'cs47l63_register_encoding']]]
];
