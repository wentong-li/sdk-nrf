var searchData=
[
  ['code',['code',['../structcs47l63__register__encoding.html#a12b4af1a81941c6ab08bec6cd507a1c2',1,'cs47l63_register_encoding']]],
  ['config',['config',['../structcs47l63__t.html#a7aa85de046525792ce0c08630a27123a',1,'cs47l63_t']]],
  ['cs47l63_5fevent_5fdata',['cs47l63_event_data',['../cs47l63_8c.html#a56ad4eec8ba2b96e9369d0f19b9443db',1,'cs47l63.c']]]
];
