var searchData=
[
  ['i2c_5fdb_5fwrite',['i2c_db_write',['../structbsp__driver__if__t.html#aa73b0b4e59163f16fa0ef4521a027908',1,'bsp_driver_if_t']]],
  ['i2c_5fread_5frepeated_5fstart',['i2c_read_repeated_start',['../structbsp__driver__if__t.html#ae5aaff18522fa62a4e95f77460a819e5',1,'bsp_driver_if_t']]],
  ['i2c_5freset',['i2c_reset',['../structbsp__driver__if__t.html#a133e128c63f4e8d4a7b9a91033861695',1,'bsp_driver_if_t']]],
  ['i2c_5fwrite',['i2c_write',['../structbsp__driver__if__t.html#a7e1b68f4df465cdfc9ca4e638a3270db',1,'bsp_driver_if_t']]],
  ['id',['id',['../structcs47l63__control__request__t.html#a2d11d2ce6be3a759fd44c0324109833e',1,'cs47l63_control_request_t']]],
  ['introduction',['Introduction',['../index.html',1,'']]],
  ['irq_5freg_5ft',['irq_reg_t',['../structirq__reg__t.html',1,'']]]
];
