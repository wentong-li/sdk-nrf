var searchData=
[
  ['debug_5fprintf',['debug_printf',['../cs47l63_8h.html#acb2150750f34fc8012902e89ffda7e10',1,'cs47l63.h']]]
];
