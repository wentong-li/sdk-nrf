var searchData=
[
  ['cs47l63_5fnotification_5fcallback_5ft',['cs47l63_notification_callback_t',['../cs47l63_8h.html#a9402fadc05b6b70ee2d35e740cde05ce',1,'cs47l63.h']]]
];
