var searchData=
[
  ['fw_5finfo',['fw_info',['../structcs47l63__dsp__t.html#aff7192bcdebc9069fe5cbe652b57c0b7',1,'cs47l63_dsp_t']]]
];
