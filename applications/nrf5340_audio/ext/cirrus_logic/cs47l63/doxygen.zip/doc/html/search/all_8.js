var searchData=
[
  ['mode',['mode',['../structcs47l63__t.html#a4abc05cd5b27c0018d251388d69389b2',1,'cs47l63_t']]]
];
