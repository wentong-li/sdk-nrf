var searchData=
[
  ['set_5fgpio',['set_gpio',['../structbsp__driver__if__t.html#a70afcf1a76958fba2a8f85dbd220dd83',1,'bsp_driver_if_t']]],
  ['set_5fsupply',['set_supply',['../structbsp__driver__if__t.html#aa399aa589bb0f95732b1710fc97ca3f6',1,'bsp_driver_if_t']]],
  ['set_5ftimer',['set_timer',['../structbsp__driver__if__t.html#a1586994324a4a49f60a116dc6f6d59de',1,'bsp_driver_if_t']]],
  ['spi_5fread',['spi_read',['../structbsp__driver__if__t.html#affa3c679ade482e0bcd09e44e9dc16a9',1,'bsp_driver_if_t']]],
  ['spi_5frestore_5fspeed',['spi_restore_speed',['../structbsp__driver__if__t.html#abfcc7cd8c48dcde1b896bd4f7dfed70d',1,'bsp_driver_if_t']]],
  ['spi_5fthrottle_5fspeed',['spi_throttle_speed',['../structbsp__driver__if__t.html#ab79f6761c94f11a643a2e8d22e486128',1,'bsp_driver_if_t']]],
  ['spi_5fwrite',['spi_write',['../structbsp__driver__if__t.html#a5ad22c13d70045408dfcde74b8d7634c',1,'bsp_driver_if_t']]],
  ['state',['state',['../structcs47l63__t.html#aac1e9780c219f6fc0fd3bd6756675c18',1,'cs47l63_t']]],
  ['syscfg_5freg_5fdescriptor_5ft',['syscfg_reg_descriptor_t',['../structsyscfg__reg__descriptor__t.html',1,'']]],
  ['syscfg_5freg_5flist_5fentry_5ft',['syscfg_reg_list_entry_t',['../structsyscfg__reg__list__entry__t.html',1,'']]],
  ['syscfg_5fregs',['syscfg_regs',['../structcs47l63__config__t.html#ab94d3820e388ea8c22f5bdfa7460560c',1,'cs47l63_config_t']]],
  ['syscfg_5fregs_5ftotal',['syscfg_regs_total',['../structcs47l63__config__t.html#a2b5ef3c183a196c77fc40836e8611147',1,'cs47l63_config_t']]]
];
