var searchData=
[
  ['base_5faddr',['base_addr',['../structcs47l63__dsp__t.html#aa8cd7d123da605009a476eb78628f39b',1,'cs47l63_dsp_t']]],
  ['bsp_5fconfig',['bsp_config',['../structcs47l63__config__t.html#ae7aedd76b62e241e3c92f331fbb6a99d',1,'cs47l63_config_t']]],
  ['bsp_5fdcvdd_5fsupply_5fid',['bsp_dcvdd_supply_id',['../structcs47l63__bsp__config__t.html#af55f1c5288de5e126daee7ed0aa87f3e',1,'cs47l63_bsp_config_t']]],
  ['bsp_5fdev_5fid',['bsp_dev_id',['../structcs47l63__bsp__config__t.html#ad7739b422c14edbf545e991ced5f9b83',1,'cs47l63_bsp_config_t']]],
  ['bsp_5fdriver_5fif_5fg',['bsp_driver_if_g',['../bsp__driver__if_8h.html#af9eab00f5b6129ff32f07ba0697df57d',1,'bsp_driver_if.h']]],
  ['bsp_5fint_5fgpio_5fid',['bsp_int_gpio_id',['../structcs47l63__bsp__config__t.html#afec2a1f14a9358c49aaf0e12c8806b4a',1,'cs47l63_bsp_config_t']]],
  ['bsp_5freset_5fgpio_5fid',['bsp_reset_gpio_id',['../structcs47l63__bsp__config__t.html#a52e39178394d7052ffcdb67583cd86c2',1,'cs47l63_bsp_config_t']]],
  ['bus_5ftype',['bus_type',['../structcs47l63__bsp__config__t.html#a7ead6deb079e6d81dcb312b295424dc0',1,'cs47l63_bsp_config_t']]]
];
