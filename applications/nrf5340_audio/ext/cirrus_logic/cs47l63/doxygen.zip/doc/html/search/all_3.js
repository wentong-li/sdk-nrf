var searchData=
[
  ['debug_5fprintf',['debug_printf',['../cs47l63_8h.html#acb2150750f34fc8012902e89ffda7e10',1,'cs47l63.h']]],
  ['device_5fsyscfg_5fregs_2eh',['device_syscfg_regs.h',['../device__syscfg__regs_8h.html',1,'']]],
  ['devid',['devid',['../structcs47l63__t.html#a35aba9cedc248c0ae61e4b2291b68991',1,'cs47l63_t']]],
  ['disable_5firq',['disable_irq',['../structbsp__driver__if__t.html#ab7dde8dfca33bc4f538539e185c7c840',1,'bsp_driver_if_t']]],
  ['dsp_5fcore',['dsp_core',['../structcs47l63__dsp__t.html#a475b83dd79090b96bb4d4951ce672ff7',1,'cs47l63_dsp_t']]],
  ['dsp_5finfo',['dsp_info',['../structcs47l63__t.html#af7ee3d3626d7f294c39ce364088ddf85',1,'cs47l63_t']]],
  ['dsp_5freg_5ft',['dsp_reg_t',['../uniondsp__reg__t.html',1,'']]]
];
