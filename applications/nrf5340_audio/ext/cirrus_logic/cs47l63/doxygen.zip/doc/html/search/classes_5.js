var searchData=
[
  ['syscfg_5freg_5fdescriptor_5ft',['syscfg_reg_descriptor_t',['../structsyscfg__reg__descriptor__t.html',1,'']]],
  ['syscfg_5freg_5flist_5fentry_5ft',['syscfg_reg_list_entry_t',['../structsyscfg__reg__list__entry__t.html',1,'']]]
];
